function [ lower,super] = dimension_bound( D )
%DIAMETER_GRAPH give the lower and upper bound of partition dimension of 
%graph G
%  D is a distance matrix of graph G
super=size(D,1)-max(D(:))+1;
lower=ceil(log(size(D,1))/log(max(D(:))+1));

end

