function [ partition,part] = partition( Pop )
%PARTITION Computing the partition of the individual
%   
partition=cell(size(Pop,1),1); % Storing the partitions of inds
part=cell(size(Pop,1),1);      % Storing the partition labels for every ind
for j=1:size(Pop,1)
part_index=unique(Pop(j,:)); % The partition labels according to the individual j. For example, [5,6,8,21,...]
part{j}=part_index;  % the partition according to the individual j. For example, part{j}=[5,6,8,21,...]
for i=1:length(part_index)
partition{j}{i}=find(Pop(j,:)==part_index(i));  % For each of the individuals, 
                                                % finding the vertices which have partition label i
                                                % It is to construct the
                                                % partition classes of ind
                                                % j.                                                                                          
end
end
end

