function [ adapt,elite, opt_value,opt_adapt] = Modify_fitness( obj_value,adapt )
%REPAIR_ADAPT Modify fitness values of elite individual
[adapt_sort,index]=sortrows(adapt);
Adapt=[adapt_sort,index];
opt_adapt=Adapt(end,1);
opt_value=obj_value(Adapt(end,2));
c= Adapt(:,1)==opt_adapt;
elite=Adapt(c,2);
ave=mean(Adapt(:,1));
for i=1:length(elite)
    adapt(elite(i))=adapt(elite(i))-ave;
    if adapt(elite(i))<0
        adapt(elite(i))=0;
    end
    
end


end

