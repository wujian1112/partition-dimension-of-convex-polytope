function [ Pop ] = mutation(N_pop,n,Pop,Pm,super)
%MUTATION �������
%   
for i=1:N_pop
    temp1=Pm*ones(1,n);
    temp2=rand*ones(1,n);
    temp3=temp1-temp2;
    index=find(temp3>0);
    temp4=randsample(1:super,n,true);
    Pop(i,index)=temp4(index);
    
end
end

