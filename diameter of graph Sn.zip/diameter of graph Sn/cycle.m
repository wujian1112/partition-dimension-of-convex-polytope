function [ output_cycle ] = cycle( num_vertex )
%CYCLE Generate a cycle with 'num_vertex' vertices
%   Input the number 'num_vertex' of vertices
%   Output a cycle 'output_cycle' 
vector=ones(1,num_vertex-1);
output_cycle=diag(vector,-1)+diag(vector,1);
output_cycle(1,num_vertex)=1;
output_cycle(num_vertex,1)=1;

end

