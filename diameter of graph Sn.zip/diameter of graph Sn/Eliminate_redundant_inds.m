function [ adapt2,t,h] = Eliminate_redundant_inds(Pop,adapt,obj_value,R_inds)
%REMOVE_REDUNDANT_INDS Eliminate redundant individuals
adapt2=adapt;
    
%      iter=500;
     N_rep=floor(R_inds*size(Pop,1));
%     N_rep=5;
   [~,~,n]= unique(Pop,'rows'); % Find all distinct individuals, which are stored in array n
   t=0;
   h=0;
 for i=1:length(n)
       temp1=find(n==n(i)); % Find all individuals having the same code
    if length(temp1)>=2
        t=t+1;
       temp2=temp1(2:end);% Except one individual
       adapt2(temp2)=0;% Set the adaptive degree zero for the individuals having the same code except one
    else
        temp3=find(obj_value==obj_value(n(i)));% Find all individuals having the same objective value
        if length(temp3)>N_rep
            h=h+1;
            adapt2(temp3(N_rep+1:end))=0;% Set the adaptive degree zero for the redundant individuals
        end
     end
 end
   
    


end

