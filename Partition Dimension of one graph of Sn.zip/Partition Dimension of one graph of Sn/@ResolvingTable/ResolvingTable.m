classdef ResolvingTable<handle
    %RESOLVINGTABLE Output the ResolvingTable of a graph.
    %input AdjacentMatrix or generate Random AdjacentMatrix for a graph
    %Methods of geting a graph, reading a graph.
    
    properties
        AdjacentMatrix;
    end
    
    methods
        function obj=ResolvingTable()   
        end
        GenerateGraphFromTxt(obj,filename);  
        GenerateRandomGraph(obj,n,p);
        [D1] = DealMatrix(obj);
        [D2] = DistanceMatrix (obj);
        [D3] = ResolvingMatrix(obj);
        [RT2table]=GetTable(obj);
    end
    
end

