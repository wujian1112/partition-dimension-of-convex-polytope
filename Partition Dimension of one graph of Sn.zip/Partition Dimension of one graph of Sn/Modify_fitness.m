function [ fit,elite] = Modify_fitness(fit )
%REPAIR_ADAPT Modify fitness values of elite individual
 [adapt_sort,index]=sortrows(fit);
 Adapt=[adapt_sort,index];
 opt_fit=Adapt(end,1);
% %opt_ind=Pop(Adapt(end,2),:);
% opt_value=obj_value(Adapt(end,2));
% temp=find(obj_value==opt_value);
% opt_ind=Pop(temp(1),:);
c= Adapt(:,1)==opt_fit;
elite=Adapt(c,2);
ave=mean(Adapt(:,1));
for i=1:length(elite)
    fit(elite(i))=fit(elite(i))-ave;
    if fit(elite(i))<0
        fit(elite(i))=0;
    end
    
end


end

