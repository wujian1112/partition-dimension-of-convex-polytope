clear;
clc;
saveVarsMat = load('pdn2\pd_n-2.mat');
A = saveVarsMat.A; % <35x35 double> too many elements
n=size(A,1);
P=GraphPlot(0);
[x,y] =P.cordinate_wheel_subd( n);
[ adj_table] = P.adjcent_table(A);
[ adj_table_handle] =P.adjcent_table_graph(n,adj_table,x,y);